print('Hello! Welcome to the Compatability calculator!')

fn = input("What is your name?:\n")
sn = input("What is their name?:\n")

both_names = fn + sn
lower_names = both_names.lower()

t = lower_names.count("t")
r = lower_names.count("r")
u = lower_names.count("u")
e = lower_names.count("e")

b = lower_names.count("b")
o = lower_names.count("o")
n = lower_names.count("n")
d = lower_names.count("d")

true = t + r + u + e
bond = b + o + n + d

bonding_score = int(true) + int(bond)

if bonding_score <= 20:
   print(f"Your bond is {bonding_score}, you go together like, glue even though you may differ so much or not at all")
elif bonding_score <= 50:
  print(f'Your bond so far is {bonding_score}, theres some potential, be wary')
elif bonding_score >=70:
    print(f"Your Bond is {bonding_score},  Very potentionally strong!!")
else:
  print(f"Your bond is {bonding_score}")
